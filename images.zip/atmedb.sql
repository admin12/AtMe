-- phpMyAdmin SQL Dump
-- version 2.11.9.4
-- http://www.phpmyadmin.net
--
-- Host: 97.74.218.25
-- Generation Time: Aug 15, 2010 at 11:57 AM
-- Server version: 5.0.91
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `atmedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `atme_comments`
--

CREATE TABLE `atme_comments` (
  `msgid` int(11) NOT NULL auto_increment,
  `user_id` varchar(32) NOT NULL,
  `posteduser` varchar(32) NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY  (`msgid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `atme_comments`
--

INSERT INTO `atme_comments` VALUES(18, '11', '6', '2010-08-13 17:07:08', 'suupsuuuupsuuuup?');
INSERT INTO `atme_comments` VALUES(17, '11', '6', '2010-08-13 17:06:58', 'sup?????');
INSERT INTO `atme_comments` VALUES(16, '11', '6', '2010-08-13 17:06:53', 'SUP?');
INSERT INTO `atme_comments` VALUES(4, '3', '1', '2010-08-12 22:53:17', 'you...are...iron...mann');
INSERT INTO `atme_comments` VALUES(5, '2', '1', '2010-08-12 22:54:52', 'bro?brobrobro...');
INSERT INTO `atme_comments` VALUES(6, '40', '6', '2010-08-12 17:10:49', 'OMG I HOPE YOUR CONTRACTZ STAYS');
INSERT INTO `atme_comments` VALUES(7, '38', '4', '2010-08-12 17:06:26', 'SUP? \r\n');
INSERT INTO `atme_comments` VALUES(8, '39', '2', '2010-08-12 17:07:08', 'Kevin, so we meet again! ');
INSERT INTO `atme_comments` VALUES(9, '38', '6', '2010-08-12 17:07:10', 'sup?');
INSERT INTO `atme_comments` VALUES(10, '2', '6', '2010-08-12 17:09:44', 'YOYOYOOYOOYOYOYOO');
INSERT INTO `atme_comments` VALUES(12, '7', '6', '2010-08-12 16:18:21', 'hey!');
INSERT INTO `atme_comments` VALUES(19, '12', '2', '2010-08-13 18:11:17', 'bro boro oro oro frorofofroro BROOOOO');
INSERT INTO `atme_comments` VALUES(29, '19', '2', '2010-08-13 19:15:46', 'e-mail, every user gets an e-mail address, and all mail comes shows up with the notifications or "daily updates" ');
INSERT INTO `atme_comments` VALUES(27, '19', '2', '2010-08-13 19:07:37', 'Add add respective profile image every time someone''s name shows up');
INSERT INTO `atme_comments` VALUES(28, '19', '2', '2010-08-13 19:09:23', 'Make profile picture clickable leading to a media gallery, pictures, videos, music ');
INSERT INTO `atme_comments` VALUES(22, '19', '2', '2010-08-13 18:56:46', 'Universal Calender - A place where you can edit the calender to include important dates, and updates show up on users profiles along with their custom updates');
INSERT INTO `atme_comments` VALUES(23, '19', '2', '2010-08-13 18:58:46', 'Mini Profile - On the home page a mini condensed profile that shows live updates of how people are reacting your profile and new comments and event invitations and so on');
INSERT INTO `atme_comments` VALUES(24, '19', '2', '2010-08-13 18:59:34', 'Use my Logo - HAHAHAHAHAHA');
INSERT INTO `atme_comments` VALUES(25, '19', '2', '2010-08-13 19:00:58', 'Status Updates - You''re going to have to eventually ');
INSERT INTO `atme_comments` VALUES(26, '19', '2', '2010-08-13 19:01:26', 'Status Updates - Or twitter integration...');
INSERT INTO `atme_comments` VALUES(30, '19', '1', '2010-08-13 19:55:44', 'I had something, but I forgot it :(');
INSERT INTO `atme_comments` VALUES(31, '4', '6', '2010-08-14 00:04:41', 'so... you''re a cat. What''s that about?');
INSERT INTO `atme_comments` VALUES(32, '1', '5', '2010-08-14 00:41:37', 'Google! You suck!');
INSERT INTO `atme_comments` VALUES(33, '13', '5', '2010-08-14 01:00:29', 'heyyyyyy!');
INSERT INTO `atme_comments` VALUES(35, '19', '19', '2010-08-14 01:23:03', 'This bitch needs an administrator screen.');
INSERT INTO `atme_comments` VALUES(36, '13', '7', '2010-08-14 21:11:05', 'I''d like to know now if you''re going to suck this year or not. I don''t like finding out half way through the season.');
INSERT INTO `atme_comments` VALUES(37, '18', '7', '2010-08-14 22:26:48', 'I have no idea who this is');
INSERT INTO `atme_comments` VALUES(38, '5', '7', '2010-08-14 23:31:18', 'you were a fad');

-- --------------------------------------------------------

--
-- Table structure for table `atme_users`
--

CREATE TABLE `atme_users` (
  `id` int(11) NOT NULL auto_increment,
  `userlvl` int(1) NOT NULL default '1',
  `confirm` tinyint(1) NOT NULL,
  `date` date NOT NULL,
  `birthdate` date default NULL,
  `birthpub` tinyint(1) NOT NULL,
  `name` varchar(24) NOT NULL,
  `username` varchar(16) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(32) NOT NULL,
  `picture` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `atme_users`
--

INSERT INTO `atme_users` VALUES(1, 1, 1, '2010-07-29', '1997-09-15', 1, 'Google', 'Google', '759730a97e4373f3a0ee12805db065e3a4a649a5', 'googleplex@gmail.com', 'Google.jpg');
INSERT INTO `atme_users` VALUES(2, 1, 1, '2010-07-31', '1989-07-02', 0, 'Aaron Chandra', 'ZenithPowers', '901a6a1774628756aff2bcff09e12aa47e3d92ab', 'aaron_chandra911@hotmail.com', 'Untitled-2.jpg');
INSERT INTO `atme_users` VALUES(3, 1, 1, '2010-08-02', NULL, 0, 'Iron Mann', 'ironmann', 'cbf41f5b461cea4e1e261d2918d5334bee8c6a06', 'ironmann@gmail.com', 'ironman.gif');
INSERT INTO `atme_users` VALUES(4, 1, 1, '2010-08-04', '1995-07-13', 1, 'snowball', 'snowball', 'cbf41f5b461cea4e1e261d2918d5334bee8c6a06', 'snowball@shaw.ca', 'cat.jpg');
INSERT INTO `atme_users` VALUES(5, 1, 1, '2010-08-04', '2009-06-01', 1, 'Microsoft Bing', 'msbing', '25bfcb9c7cd45caae2c420b529dccacf1611afc3', 'bing@live.ca', 'msbing20100813174933.jpg');
INSERT INTO `atme_users` VALUES(6, 2, 1, '2010-08-04', '1989-05-07', 1, 'Kevin Mann', 'mrmann14', '777f7869c8d6b902815b27b0843a2c7d4c5cc96b', 'kma50@sfu.ca', 'sunny.jpg');
INSERT INTO `atme_users` VALUES(7, 3, 1, '2010-08-04', '1920-01-18', 1, 'David Lindberg', 'david', 'd2da29bdd5ea25c5eb1666858e7e2ae441465b98', 'lindberg.david@gmail.com', 'Image.jpg');
INSERT INTO `atme_users` VALUES(8, 1, 1, '2010-08-04', '1965-07-02', 1, 'Spidey Mann', 'spiderman', '368f976940775c710aec525fe1e349f8a1fb9a39', 'kma50@sfu.ca', 'spiderman.gif');
INSERT INTO `atme_users` VALUES(9, 1, 1, '2010-08-04', NULL, 0, 'Sean Maloney', 'Sean', '0fa26ba424a2d9bc818d7b08c93b1a9e694127ef', 'the.instant.classic@hotmail.com', 'nopic.jpg');
INSERT INTO `atme_users` VALUES(10, 1, 1, '2010-08-05', '1965-09-09', 1, 'Bat Mann', 'Batman', '5c6d9edc3a951cda763f650235cfc41a3fc23fe8', 'IAMBATMAN@google.com', 'batman.jpg');
INSERT INTO `atme_users` VALUES(11, 1, 1, '2010-08-07', NULL, 0, 'Ania Dudziuk', 'annabelle', '03412822ce98db316c13cee7309689f3f2d01b39', 'funky_dumbo_415@hotmail.com', 'ania1.jpg');
INSERT INTO `atme_users` VALUES(12, 2, 1, '2010-08-08', '1989-05-07', 1, 'Kevin Mann', 'kevinmann', 'cbf41f5b461cea4e1e261d2918d5334bee8c6a06', 'mrmann14@gmail.com', '01356_crepuscule_1280x800 copy.jpg');
INSERT INTO `atme_users` VALUES(13, 1, 1, '2010-08-09', '1979-04-04', 1, 'Roberto Luongo', 'rluongo1', 'cbf41f5b461cea4e1e261d2918d5334bee8c6a06', 'rluongo@canucks.com', 'roberto-luongo.jpg');
INSERT INTO `atme_users` VALUES(14, 1, 0, '2010-08-10', '2002-04-05', 1, 'lol lol', 'lol', '403926033d001b5279df37cbbe5287b7c7c267fa', 'lol', 'nopic.jpg');
INSERT INTO `atme_users` VALUES(15, 1, 0, '2010-08-10', '2005-05-06', 1, 'lol lol', 'yahoo', '6af5a2bfa9c5935b9952a65d2df5d1b82a0588ec', 'lol', 'nopic.jpg');
INSERT INTO `atme_users` VALUES(16, 1, 0, '2010-08-10', '2005-04-05', 1, 'my my', 'mylol', '403926033d001b5279df37cbbe5287b7c7c267fa', 'lol', 'nopic.jpg');
INSERT INTO `atme_users` VALUES(17, 1, 0, '2010-08-10', '1974-03-09', 0, 'Markus Naslund', 'nassy', '4b2e608dade4dc890fa45e1e1f4a4b2dfed04633', 'nassy@canucks.com', 'nopic.jpg');
INSERT INTO `atme_users` VALUES(18, 1, 1, '2010-08-13', '1978-01-03', 1, 'Bangs TheRapper', 'BangsDaRapper', '37fd7005f1689a510f2fc42b4af8d461559560c7', 'dminfinity.scott@gmail.com', 'nopic.jpg');
INSERT INTO `atme_users` VALUES(19, 3, 1, '2010-08-13', '2010-08-01', 1, 'Kevin Mann', 'AtMe', '777f7869c8d6b902815b27b0843a2c7d4c5cc96b', 'admin@itsatme.com', 'AtMe20100813185454.png');
INSERT INTO `atme_users` VALUES(20, 1, 0, '2010-08-14', '1975-06-04', 1, 'Dan Cloutier', 'dclouts', 'cbf41f5b461cea4e1e261d2918d5334bee8c6a06', 'dclouts@canucks.com', 'nopic.jpg');
